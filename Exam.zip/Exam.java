import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

class ShortDateConverter {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a short date (YYYY-MM-DD): ");
        String shortDate = scanner.nextLine();

        try {
            SimpleDateFormat sdfInput = new SimpleDateFormat("yyyy-MM-dd");
            Date date = sdfInput.parse(shortDate);

            SimpleDateFormat sdfOutput = new SimpleDateFormat("MMMM d, yyyy");

            System.out.println("Full Date Representation: " + sdfOutput.format(date));

        } catch (ParseException e) {
            System.out.println("Invalid date format. Please enter the date in the format YYYY-MM-DD.");
        } finally {
            // Close the scanner
            scanner.close();
        }
    }
}